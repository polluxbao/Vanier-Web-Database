import java.util.Scanner;

public class StringProblem2 {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		
		// System.out.println(Math.round(2.5));
		
		System.out.println("Please input the first string: ");
		String firstWord = console.next();
		
		System.out.println("Please input the second string: ");
		String secondWord = console.next();
		
		int halfIndex = (int) Math.round(firstWord.length() / 2.0);
		
		String firstHalf = firstWord.substring(0, halfIndex);
		String secondHalf = secondWord.substring(secondWord.length() / 2);
		
		System.out.println("The output is: ");
		System.out.println(firstHalf + secondHalf);
		
		
		console.close();
	}

}
