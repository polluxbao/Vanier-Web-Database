import java.util.Scanner;

public class StringProblem1 {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		
		System.out.println("Please input a word: ");
		
		String input = console.next();
		
//		char firstLetter = input.charAt(0);
//		char lastLetter = input.charAt(input.length() - 1);
		
		String firstLetter = input.substring(0, 1);
		String lastLetter = input.substring(input.length() - 1);
		
		System.out.println("Output is: ");
		System.out.println(firstLetter + lastLetter);
		
		// System.out.println(lastLetter);
		
		console.close();
	}

}
