import java.util.Scanner;

public class StringProblem3 {

	public static void main(String[] args) {
		Scanner console = new Scanner(System.in);
		
		System.out.println("Please input the first string: ");
		String firstWord = console.next();
		
		System.out.println("Please input the second string: ");
		String secondWord = console.next();
		
		firstWord = firstWord.toLowerCase();
		secondWord = secondWord.toLowerCase();
		
		System.out.println("The output is: ");
		// System.out.println(firstWord + " " + secondWord);
		
		String result = "";
		
		result = result.concat(firstWord);
		result = result.concat(" ");
		result = result.concat(secondWord);
		
		System.out.println(result);
		
		console.close();
	}

}
