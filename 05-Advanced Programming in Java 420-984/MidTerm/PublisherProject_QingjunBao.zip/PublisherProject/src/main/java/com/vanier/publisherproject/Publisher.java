/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.publisherproject;

/**
 *
 * @author Administrator
 */
public class Publisher {
    private int pub_Id;
    private String pub_Name;
    private String pub_Address;
    
    Publisher() {
        pub_Id = 0;
        pub_Name = "";
        pub_Address = "";
    }
        
    Publisher(int id, String name, String address) {
        pub_Id = id;
        pub_Name = name;
        pub_Address = address;
    }
    
    public void setPub_Id(int id) {
        pub_Id = id;
    }
    
    public void setPub_Name(String name) {
        pub_Name = name;
    }
    
    public void setPub_Address(String address) {
        pub_Address = address;
    }
    
    public int getPub_Id() {
        return pub_Id;
    }
    
    public String getPub_Name() {
        return pub_Name;
    }
    
    public String getPub_Address() {
        return pub_Address;
    }    
    
    public String toString() {
        return ("Publisher Id : " + pub_Id
            + ", Publisher Name : " + pub_Name
            + ", Publisher Address : " + pub_Address);
    }
    
}
