/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package com.vanier.publisherproject;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class TestPublisherProject {
    public static void main(String[] args) {
        Scanner scaner = new Scanner(System.in);
        System.out.printf("Enter Publisher Id: ");
        int Id = scaner.nextInt();
        System.out.printf("Enter Publisher Name: ");
        String Name = scaner.next();
        System.out.printf("Enter Publisher Address: ");
        String Address = scaner.next();
        
        Publisher publisher = new Publisher(Id, Name,Address);
        System.out.println("The new yourPublisher Object: " + publisher);
        
        System.out.println("To Access the data members of yourPublisher Object Using the getter method.");

        System.out.printf("Publisher Id: " + publisher.getPub_Id());
        System.out.printf("Publisher Name " + publisher.getPub_Name());
        System.out.printf("Publisher Address: " + publisher.getPub_Address());
    }
}
