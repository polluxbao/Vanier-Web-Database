package com.vanier.generaltripproject;

public class Trip {
    private double cost_trip;
    
    private double gas_price;
    private int distance;
    private int cost_hotel;
    private int cost_food;
    
    Trip(){};
    
    Trip(double u_gas_price, int u_distance, int u_cost_hotel, int u_cost_food){
        gas_price = u_gas_price;
        distance = u_distance;
        cost_hotel = u_cost_hotel;
        cost_food = u_cost_food;
    };
            
    public double CalculateCostTrip() {
        cost_trip = (distance * gas_price) + cost_hotel + cost_food;
        return cost_trip;
    }
    
    public void setGasPrice(double u_gas_price) {
        gas_price = u_gas_price;
    }
    
    public void setDistance(int u_distance) {
        distance = u_distance;
    }
    
    public void setCostHotel(int u_cost_hotel) {
        cost_hotel = u_cost_hotel;
    }
    
    public void setCostFood(int u_cost_food) {
        cost_food = u_cost_food;
    }
    
    public double getGasPrice() {
        return gas_price;
    }
    
    public int getDistance() {
        return distance;
    }
    
    public int getCostHotel() {
        return cost_hotel;
    }
    
    public int getCostFood() {
        return cost_food;
    }
    
    
}
