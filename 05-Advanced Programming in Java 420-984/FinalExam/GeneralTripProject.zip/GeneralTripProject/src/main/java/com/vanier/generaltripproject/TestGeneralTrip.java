package com.vanier.generaltripproject;

public class TestGeneralTrip {

    public static void main(String[] args) {
        TripGInterface yourTripObj = new TripGInterface();
    }
}
