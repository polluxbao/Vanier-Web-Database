package com.vanier.generaltripproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class TripGInterface extends JFrame implements ActionListener {
    JTextField u_gas_priceTF, u_distanceTF, u_cost_hotelTF, u_cost_foodTF;
    JTextField u_cost_yourTripTF, u_cost_myTripTF;
    public TripGInterface() {
        //Create the 6 labels
        JLabel u_gas_price = new JLabel("Enter Gas Price: ", SwingConstants.RIGHT);
        JLabel u_distance = new JLabel("Enter Distance: ", SwingConstants.RIGHT);
        JLabel u_cost_hotel = new JLabel("Enter Cost Hotel: ", SwingConstants.RIGHT);
        JLabel u_cost_food = new JLabel("Enter The Cost Food: ", SwingConstants.RIGHT);
        JLabel u_cost_yourTrip = new JLabel("The Cost of Trip(yourTrip Object): ", SwingConstants.RIGHT);
        JLabel u_cost_myTrip = new JLabel("The Cost of Trip(myTrip Object): ", SwingConstants.RIGHT);
        
        //Create the 6 text fields
        u_gas_priceTF = new JTextField(10);
        u_distanceTF = new JTextField(10);
        u_cost_hotelTF = new JTextField(10);
        u_cost_foodTF = new JTextField(10);
        u_cost_yourTripTF = new JTextField(10);
        u_cost_myTripTF = new JTextField(10);
        
        //Create Calculate Button
        JButton calculateB = new JButton("Calculate");
        
        //Associate or register this listener with the corresponding JButton
        calculateB.addActionListener(this);
        
        //Create Exit Buttonthis
        JButton exitB = new JButton("Exit");
        //Associate or register this listener with the corresponding JButton
        exitB.addActionListener(this);
        
        //Set the title of the window
        setTitle("Trip Bidgeting Application");

        //Get the container
        Container pane = getContentPane();

        //Set the layout
        pane.setLayout(new GridLayout(7, 2));
        
        //Place the components in the pane
        pane.add(u_gas_price);
        pane.add(u_gas_priceTF);
        
        pane.add(u_distance);
        pane.add(u_distanceTF);
        
        pane.add(u_cost_hotel);
        pane.add(u_cost_hotelTF);
        
        pane.add(u_cost_food);
        pane.add(u_cost_foodTF);
        
        pane.add(u_cost_yourTrip);
        pane.add(u_cost_yourTripTF);
        
        pane.add(u_cost_myTrip);
        pane.add(u_cost_myTripTF);
        
        pane.add(calculateB);
        pane.add(exitB);
        
        //Set the size of the window and display it
        setSize(400, 300);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("Calculate")) {
            double u_gas_priceInput, u_CostHourInput;
            int u_distanceInput, u_cost_hotelInput, u_cost_foodInput;
            double u_cost_yourTripOutput, u_cost_myTripOutput;

            u_gas_priceInput = Double.parseDouble(u_gas_priceTF.getText());
            u_distanceInput = Integer.parseInt(u_distanceTF.getText());
            u_cost_hotelInput = Integer.parseInt(u_cost_hotelTF.getText());
            u_cost_foodInput = Integer.parseInt(u_cost_foodTF.getText());

            Trip yourTrip = new Trip();
            
            yourTrip.setGasPrice(u_gas_priceInput);
            yourTrip.setDistance(u_distanceInput);
            yourTrip.setCostHotel(u_cost_hotelInput);
            yourTrip.setCostFood(u_cost_foodInput);
            
            Trip myTrip = new Trip(5.0, 4, u_cost_hotelInput, 20);
            
            u_cost_yourTripOutput = yourTrip.CalculateCostTrip();
            u_cost_myTripOutput = myTrip.CalculateCostTrip();
            
            u_cost_yourTripTF.setText(String.format("%.2f", u_cost_yourTripOutput).toString() + "$");
            u_cost_myTripTF.setText(String.format("%.2f", u_cost_myTripOutput).toString() + "$");
            
        } else if(e.getActionCommand().equals("Exit")) {
            System.exit(0);
        }  //End of ActionPerformed interface Method
    }
}

