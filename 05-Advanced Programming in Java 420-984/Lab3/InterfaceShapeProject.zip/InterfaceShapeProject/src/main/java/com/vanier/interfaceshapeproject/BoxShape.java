package com.vanier.interfaceshapeproject;

public class BoxShape extends RectangleShape implements AngleShape {
    private double height;
    
    public BoxShape() {
        super();
        height = 0;
    }
    
    public BoxShape(double l, double w, double h) {
        super(l, w);
        if( h>=0 ) height = h;
        else height = 0;
    }
    
    public double getHeight() {
        return height;
    }
    
    @Override
    public double area() {
        return 2 * (super.getLength() * super.getWidth()
                + super.getLength() * height
                + super.getWidth() * height);
    }
    
    public double volume() {
        return super.area() * height;
    }
    
    public String toString() {
        return "Length = " + super.getLength() 
                + ", Width = " + super.getWidth()
                + ", Height = " + height
                + ", Surface Area = " + area() 
                + ", Volume = " + volume();
    }
    
    public void printShapeInfo() {
        System.out.println("Length = " +  super.getLength()
                        + ", Width = " + super.getWidth()
//                        + ", Height = " + height
                        + ", angle shape = " + angle/2);
    }
}
