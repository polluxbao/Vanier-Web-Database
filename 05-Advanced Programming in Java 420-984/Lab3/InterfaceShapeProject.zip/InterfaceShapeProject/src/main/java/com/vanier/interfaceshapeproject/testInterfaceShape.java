package com.vanier.interfaceshapeproject;

public class testInterfaceShape {


    public static void main(String[] args) {
        RectangleShape rectangle, rectRef;
        BoxShape box, boxRef;
        
        // Create a reference from abstract class
        rectangle = new RectangleShape(12, 4);                      //Line 3
        System.out.println("Line 4: Rectangle \n"
                        + rectangle + "\n");                        //Line 4
        
        System.out.println("\nPolymorphism: Invoking Subclass method "
                        + "with superclass object reference: "
                        + rectangle.area() + "\n");
            
        AngleShape angleShapeRef;
        
        // Calling method defined in Interface AngleShape
        angleShapeRef = rectangle;
        System.out.println("1-Calling method defined in interface AngleShape:");
        angleShapeRef.printShapeInfo();
        
        rectangle = new RectangleShape(12, 4);                      //Line 6
        System.out.println("Line 6: Rectangle \n"
                        + rectangle + "\n");                        //Line 7

        // Polymorphism via interface
        boxRef = new BoxShape(10, 2, 3); 
        angleShapeRef = boxRef;                                     //Line 8
  
        // Calling method defined in Interface AngleShape
        System.out.println("2-Calling method defined in interface AngleShape:");
        angleShapeRef = rectangle;
        angleShapeRef.printShapeInfo();
                
        boxRef = new BoxShape(10, 2, 3);                            //Line 9
        System.out.println("Line 6: boxRef \n"
                        + boxRef + "\n");                           //Line 10
        
        // Polymorphism interface
        angleShapeRef = boxRef;                                     //Line 11
        // Calling method defined in Interface AngleShape
        System.out.println("3-Calling method defined in interface AngleShape:");
        angleShapeRef.printShapeInfo(); 
    }
}
