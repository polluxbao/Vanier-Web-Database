
package com.vanier.interfaceshapeproject;

public interface AngleShape {
    public double angle = 45;
    public void printShapeInfo();
    
}
