package com.vanier.compositionshapeproject;

/**
 *
 * @author Administrator
 */
public class testCompositionShape {
    public static void main(String[] args) {
        RectangleShape rectangle, rectRef;                      //Line 1
        BoxShape box, boxRef;                                   //Line 2
        
        Shape refShape;
                
        rectangle = new RectangleShape(12, 4);                  //Line 3
        System.out.println("Line 4: Rectangle \n"
                        + rectangle + "\n");                    //Line 4
        
        // Polymorphism
        refShape = rectangle;                                   //Line 5
        System.out.println("\nPolymorphism: Invoking Subclass method "
                        + "with superclass object reference: "
                        + refShape.area() + "\n");
        
        // Calling method defined in Interface AngleShape
        System.out.println("Calling method defined in interface AngleShape:");
        rectangle.printShapeInfo();
        
        // Using Composition of the class Circle
        rectangle.circle1.setRadius(45.0);
        System.out.println("Using Composition, the radius Subject:"
                        + rectangle.circle1.getRadius());


    }
    
}
