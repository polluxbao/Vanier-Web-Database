package com.vanier.compositionshapeproject;

/**
 *
 * @author Administrator
 */
public class CompositionShapeProject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
