/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.compositionshapeproject;

/**
 *
 * @author Administrator
 */
public abstract class Shape {
    //area is overloading method in BoxShape and RectangleShape
    public abstract double area();
    
}