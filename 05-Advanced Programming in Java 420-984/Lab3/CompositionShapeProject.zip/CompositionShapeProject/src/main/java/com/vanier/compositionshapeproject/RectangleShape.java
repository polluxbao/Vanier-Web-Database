/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.compositionshapeproject;

/**
 *
 * @author Administrator
 */
public class RectangleShape extends Shape implements AngleShape {

    protected double length;
    protected double width;
    public Circle circle1;
    
    public RectangleShape() {
        length = 0;
        width = 0;
        circle1 = new Circle();
    }
    
    public RectangleShape(double l, double w) {
        if(l >=0 ) length = l;
        else length =0;
        
        if(w >= 0) width = w;
        else width = 0;
        
        circle1 = new Circle();
    }
    
    public double perimeter() {
        return 2 * (length + width);
    }
    
    public double area() {
        return length * width;
    }
    
    public double getLength() {
        return length;
    }

    public double getWidth() {
        return width;
    }
    
    
    public String toString() {
        return "Length = " + length 
                + ", Width = " + width
                + ", Perimeter = " + perimeter() 
                + ", Area = " + area();
    }
    
    public void printShapeInfo() {
        System.out.println("Length = " + length
                        + ", Width = " + width
                        + ", angle shape = " + angle);
    }
    
}