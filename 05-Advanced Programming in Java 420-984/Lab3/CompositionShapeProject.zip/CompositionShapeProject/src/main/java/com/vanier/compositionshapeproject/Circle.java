/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.compositionshapeproject;

/**
 *
 * @author Administrator
 */
public class Circle {
    private double radius;
    
    Circle() {
        radius = 0;
    }
    
    Circle(double r) {
        radius = r;
    }
    
    
    public void setRadius(double r) {
        radius = r;
    }
    
    public double getRadius() {
        return radius;
    }
    
}
