/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.abstractshapeproject;

/**
 *
 * @author Administrator
 */
public class testInterfaceShape {
    public static void main(String[] args) {
        RectangleShape rectangle, rectRef;
        BoxShape box, boxRef;
        
        AngleShape angleShapeRef;
        
        rectangle = new RectangleShape(12, 4);                      //Line 6
        System.out.println("Line 4: Rectangle \n"
                        + rectangle + "\n");                        //Line 7
        
        // Polymorphism
        angleShapeRef = rectangle;                                  //Line 8
        
        // Calling method defined in Interface AngleShape
        System.out.println("Calling method defined in interface AngleShape:");
        angleShapeRef.printShapeInfo();
                
        boxRef = new BoxShape(10, 2, 3);                            //Line 9
        System.out.println("Line 6: boxRef \n"
                        + boxRef + "\n");                           //Line 10
        
        // Polymorphism interface
        angleShapeRef = boxRef;                                     //Line 11
        // Calling method defined in Interface AngleShape
        System.out.println("Calling method defined in interface AngleShape:");
        angleShapeRef.printShapeInfo();        
        
    }
}
