package com.vanier.abstractshapeproject;

public abstract class Shape {
    //area is overloading method in BoxShape and RectangleShape
    public abstract double area();
}
