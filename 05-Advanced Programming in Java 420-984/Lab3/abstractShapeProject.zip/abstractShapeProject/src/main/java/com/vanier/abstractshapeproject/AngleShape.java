/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.abstractshapeproject;

/**
 *
 * @author Administrator
 */
public interface AngleShape {
    public double angle = 45;
    public void printShapeInfo();
    
}
