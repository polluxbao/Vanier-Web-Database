/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.vanier.abstractshapeproject;

/**
 *
 * @author Administrator
 */
public class testAbstractShape {
    public static void main(String[] args) {
        RectangleShape rectangle, rectRef;                      //Line 1
        BoxShape box, boxRef;                                   //Line 2
        
        Shape refShape;
                
        rectangle = new RectangleShape(12, 4);                  //Line 3
        System.out.println("Line 4: Rectangle \n"
                        + rectangle + "\n");                    //Line 4
        
        // Polymorphism
        refShape = rectangle;                                   //Line 5
        System.out.println("\nPolymorphism: Invoking Subclass method "
                        + "with superclass object reference: "
                        + refShape.area() + "\n");
        
        boxRef = new BoxShape(10, 2, 3);                        //Line 6
        System.out.println("Line 6: boxRef \n"
                        + boxRef + "\n");                       //Line 7
        
        // Polymorphism
        refShape = boxRef;                                      //Line 8
        System.out.println("\nPolymorphism: Invoking Subclass method "
                        + "with superclass object reference: "
                        + refShape.area() + "\n");

    }
}
