/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package geometryproject;

/**
 *
 * @author samir
 */
public class TestGeometryProject {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO Object Oriented Programming
        
        //Instantiating Object for manipulation
        Rectangle myrectangle1 = new Rectangle();
        Rectangle myrectangle2 = new Rectangle();
        
        Rectangle myrectangle3 = new Rectangle(5, 8); // Actual parameters
        
        //Assigning data attibutes to objects
        myrectangle1.length = 6;
        myrectangle1.width = 2;
        
        myrectangle2.length = 3;
        myrectangle2.width = 9;
        
               
        /* because I am not calling instance methods
        //print area
        //System.out.println("Area is "+ length*width); //Invalid
        System.out.println("Area is "+ myrectangle1.length*myrectangle1.width); 
        //you are not using object names
        
        //print area
        //System.out.println("Area is "+ length*width); //Invalid
        System.out.println("Area is "+ myrectangle2.length*myrectangle2.width); 
        //you are not using object names
        */
        
        //print area
        
        double areaRect =  myrectangle1.area();        
        System.out.println("Area for myrectangle1 is "+ areaRect );
        System.out.printf ("Area for myrectangle1 is %.2f%n", areaRect);
        
        areaRect =  myrectangle2.area();        
        System.out.println("Area for myrectangle2 is "+ areaRect); 
        
        areaRect =  myrectangle3.area();        
        System.out.println("Area for myrectangle3 is "+ areaRect); 
        
        //call void method as standalone statement
        System.out.println("myrectangle3 Info");
        myrectangle3.printRectangle();
       
        
        
        
        
        
    }
    
}
