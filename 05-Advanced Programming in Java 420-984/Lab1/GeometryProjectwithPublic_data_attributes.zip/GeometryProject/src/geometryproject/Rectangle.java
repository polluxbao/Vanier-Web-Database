/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package geometryproject;

/**
 *
 * @author samir
 */
public class Rectangle {
    
    //template for Data Attributes
    public double length;  //modifiers of data atributes
    public double width;   //public, private, protected
    
    //Default constructor
    public Rectangle()
    {
        length = 0;
        width = 0;
    }
    //Rectangle myrectangle3 = new Rectangle(10, 8);  in the testing 
    
    //Constructor with two formal parameters
    public Rectangle(double l, double w)
    {
        length = l;   //length = 10
        width = w;    //width = 8
    }
    
    //concrete methods
    public double area () //signature: returntype Methodname(formal parameters)
    {
            double area;
            area = length * width;
            return area;
    }
    
    public double perimeter(){
            double perimeter;
            perimeter = 2*(length+width);
            return perimeter;
    }
    
    public void printRectangle (){
            System.out.println("Lenght: "+length +" width: "+ width);
    }
    
}
