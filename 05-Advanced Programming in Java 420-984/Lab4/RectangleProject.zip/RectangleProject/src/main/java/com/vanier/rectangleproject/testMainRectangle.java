package com.vanier.rectangleproject;

public class testMainRectangle {

    public static void main(String[] args) {
        RectangleGUI testRectangleObj = new RectangleGUI();
        
    }
}
