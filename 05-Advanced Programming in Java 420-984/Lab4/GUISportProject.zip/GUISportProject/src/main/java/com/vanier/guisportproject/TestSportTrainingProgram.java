package com.vanier.guisportproject;

public class TestSportTrainingProgram {

    public static void main(String[] args) {
        SportGInterface testSportTrainingObj = new SportGInterface();
    }
}
