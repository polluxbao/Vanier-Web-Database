DROP TABLE salaries;
DROP TABLE titles;
DROP TABLE dept_emp;
DROP TABLE dept_manager;
DROP TABLE departments;
DROP TABLE employees;





