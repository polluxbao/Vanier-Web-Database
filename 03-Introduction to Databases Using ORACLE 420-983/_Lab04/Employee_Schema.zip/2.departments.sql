INSERT INTO departments (dept_no,dept_name) VALUES ('d001','Marketing');
INSERT INTO departments (dept_no,dept_name) VALUES ('d002','Finance');
INSERT INTO departments (dept_no,dept_name) VALUES ('d003','Human Resources');
INSERT INTO departments (dept_no,dept_name) VALUES ('d004','Production');
INSERT INTO departments (dept_no,dept_name) VALUES ('d005','Development');
INSERT INTO departments (dept_no,dept_name) VALUES ('d006','Quality Management');
INSERT INTO departments (dept_no,dept_name) VALUES ('d007','Sales');
INSERT INTO departments (dept_no,dept_name) VALUES ('d008','Research');
INSERT INTO departments (dept_no,dept_name) VALUES ('d009','Customer Service');
