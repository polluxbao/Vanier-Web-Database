
DROP TABLE orderdetails;
DROP  TABLE products;
DROP  TABLE productlines;
DROP  TABLE payments;
DROP  TABLE orders;
DROP  TABLE customers;
DROP  TABLE office_employees;
DROP  TABLE offices;