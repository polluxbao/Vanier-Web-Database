
WITH dates AS (
        SELECT
            From_date AS comp_date                 -- use from_date as a date to check with aka comp_Date
        FROM
            salaries
    ),
    salaries_for_every_date AS (                  -- get all salaries where comp_date falls between to and from
        SELECT *
        FROM dates, salaries
        WHERE
            comp_date BETWEEN from_date AND to_date
    ),
    min_salary_per_date AS (                       -- group records by comp_date field
        SELECT
            comp_date,
            MIN(salary) AS min_sal                 -- find min salary on given date
        FROM salaries_for_every_date
        GROUP BY
            comp_date
    ),
    emp_no_for_min_sal_per_Date AS (               -- find emp_no associated to min salaries on given dates
        SELECT comp_date, emp_no, salary
        FROM min_salary_per_date, salaries
        WHERE
            min_sal = salary AND
            comp_Date BETWEEN From_date AND to_date
    )
SELECT
    DISTINCT                                        -- print only distinct employee's names.
    first_Name | | ' ' | | last_Name AS empName
FROM emp_no_for_min_sal_per_Date
    INNER JOIN employees USING (emp_no);
